void ZigduinoSleepInit(void);

void ZigduinoSleepSet(uint8_t);

void ZigduinoSleep(void);
