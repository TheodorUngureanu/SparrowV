#include <avr/sleep.h>
#include <avr/interrupt.h>
#include "ZigduinoSleep.h"

uint32_t symbol_threshold = 0x00000000;

ISR(SCNT_CMP1_vect)
{
	
}

void ZigduinoSleepInit()
{
	sei();
	
	ASSR |= _BV(AS2); // enable asynchronous mode, with external oscillator (32.768kHz in our case) 

	SCOCR1HH = (symbol_threshold >> 24);
	SCOCR1HL = (symbol_threshold & 0x00ff0000) >> 16;
	SCOCR1LH = (symbol_threshold & 0x0000ff00) >>  8;
	SCOCR1LL = (symbol_threshold & 0x000000ff);
	SCCR0 = _BV(SCEN) ;//| _BV(SCCKSEL); 	// enable symbol counter, with TOSC1/2 clock (32.768kHz)
	SCCNTHH = 0x00;
	SCCNTHL = 0x00;
	SCCNTLH = 0x00;
	SCCNTLL = 0x00;
	
	while (SCSR & _BV(SCBSY));
	SCIRQM = _BV(IRQMCP1); 			// enable compare match 1 IRQ*/
}

void ZigduinoSleepSet(uint8_t seconds)
{
	symbol_threshold += (((uint32_t)seconds) * 62500);
	
	SCOCR1HH = (symbol_threshold >> 24);
	SCOCR1HL = (symbol_threshold & 0x00ff0000) >> 16;
	SCOCR1LH = (symbol_threshold & 0x0000ff00) >>  8;
	SCOCR1LL = (symbol_threshold & 0x000000ff);
	
	while (SCSR & _BV(SCBSY));
}

void ZigduinoSleep()
{
   set_sleep_mode(SLEEP_MODE_PWR_SAVE);
   sleep_enable();
   sleep_cpu();
   sleep_disable();
}
